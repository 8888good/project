# Meme AI · Discord 梗圖推薦 Bot

## 版本 v0.1.0

首個版本，包含 Discord 指令、Gemini／OpenAI 標籤分析、SQLite 自建庫、MemeStack 搜尋及圖片附件。

輸入文字或主動取得頻道上下文，由 Gemini 或 OpenAI 回傳兩個英文 snake_case 標籤。Bot 優先推薦同一伺服器的自建梗圖，找不到可用圖片時可查 Wikimedia Commons。

## 1. 設定 Discord 應用程式

1. 在 [Discord Developer Portal](https://discord.com/developers/applications) 建立 Application。
2. 在 **Bot** 頁面取得 Token，並在 **Privileged Gateway Intents** 啟用 **Message Content Intent**。已達 Discord 審核門檻的應用程式須取得相應核准。Token 請放入本機的 `.env`。
3. 在 **Installation** 啟用 **Guild Install**，選擇 `bot` 和 `applications.commands` scopes。Bot 權限勾選 **View Channels**、**Send Messages**、**Embed Links**、**Read Message History**。若使用討論串，也需允許 **Send Messages in Threads**。
4. 用安裝連結將 Bot 加入測試伺服器。確認測試頻道的覆寫權限允許 Bot 讀取歷史與發送訊息，也允許測試者使用應用程式指令。
5. 可在 Discord **使用者設定 → 進階** 開啟開發者模式，再右鍵點伺服器複製 ID，填入 `DISCORD_TEST_GUILD_ID` 以將指令同步到指定伺服器。留白會同步全域指令。從測試切換到全域時，可在測試伺服器的整合設定檢查舊的測試指令。

## 2. 安裝與啟動（Windows）

先安裝 Python 3.11 或更新版本並啟用 Python Launcher。在解壓後的專案目錄執行。

**PowerShell**

```powershell
py -3 -m venv .venv
.\.venv\Scripts\python.exe -m pip install -r requirements.txt
Copy-Item .env.example .env
notepad .env
.\.venv\Scripts\python.exe main.py
```

**CMD**

```bat
py -3 -m venv .venv
.venv\Scripts\python.exe -m pip install -r requirements.txt
copy .env.example .env
notepad .env
.venv\Scripts\python.exe main.py
```

先填寫 `DISCORD_BOT_TOKEN`。預設的 `LLM_PROVIDER=gemini` 需要 `GEMINI_API_KEY`，模型預設為 `gemini-flash-latest`。改用 OpenAI 時，設定 `LLM_PROVIDER=openai` 並填寫 `OPENAI_API_KEY`，模型預設為 `gpt-4o-mini`。可用 `GEMINI_MODEL` 或 `OPENAI_MODEL` 覆寫，修改後重新啟動。

SQLite 會自動建立在 `data/memes.db`。相對路徑以專案根目錄為基準。將電子郵件或 Wikimedia 使用者頁面填入 `WIKIMEDIA_CONTACT` 即可開啟網路備援，該值會用於 Wikimedia 的 HTTP User-Agent。GIPHY 搜尋規範要求由客戶端發送請求，本 Discord Bot 採用 Wikimedia Commons API，`GIPHY_API_KEY` 是保留欄位。Commons 篩選 CC0 或標記為公有領域且無已標示限制的圖片，並附上檔案頁面。熱門商業迷因在這個來源的涵蓋有限，可將你有權使用的圖片加入自建庫。

## 3. 操作與驗證

| 指令 | 如何驗證 |
| --- | --- |
| `/meme_help` | 確認 Bot 回覆四個指令的說明。 |
| `/meme_add` | 使用具「管理伺服器」權限的帳號，貼上直接 HTTPS 圖片網址，填入例如 `doge,stonks`，可加簡介。確認回傳編號，再送同一網址驗證重複提示。用一般帳號確認無法新增。 |
| `/meme` | 輸入「今天狗狗幣大漲，我好像突然懂投資了」。觀察兩個分析標籤、推薦圖片與來源。LLM 每次產生的標籤可能不同，可用實際回傳標籤建立測試資料。 |
| `/meme_recent` | 在可讀取的測試頻道發送數則相關訊息，再執行指令。Bot 取最近 12 則中的人類純文字，依時間順序送給 LLM。 |

新增圖片預設接受 `upload.wikimedia.org` 與 `i.imgur.com` 的直接網址，且伺服器必須回應成功的 HEAD 請求與支援的圖片 Content-Type。部署者可在 `IMAGE_HOSTS` 設定逗號分隔的可信公網圖片主機。圖片驗證不跟隨轉址，也不下載檔案。本地推薦會檢查最多五個排名最高的候選，避開已失效的網址。

`/meme` 與 `/meme_recent` 會將本次分析所需文字送給設定的 LLM 服務。頻道歷史只在指令觸發時讀取，Bot 訊息、Webhook 和空白訊息會略過。SQLite 只儲存自建梗圖資料，並以 Discord 伺服器分隔。網路搜尋傳送分析後的標籤。請在適合把對話送給外部 AI 的頻道開放指令。

## 4. 自動測試與單獨呼叫 LLM

```powershell
.\.venv\Scripts\python.exe -m pytest -q
.\.venv\Scripts\python.exe scripts/test_extract_tags.py "今天 deadline 又被加任務"
.\.venv\Scripts\python.exe scripts/test_extract_tags.py --provider openai "這會議可以結束了嗎"
```

pytest 模擬 Discord、LLM 與網路 API，並用暫存 SQLite 驗證資料操作。後兩行是需要所選 Provider 金鑰的實際呼叫，可能使用 API 額度。CLI 支援 `--model` 並維持 JSON 輸出格式。

```json
{"tags": ["this_is_fine", "hide_the_pain_harold"]}
```

## 程式分工

- `main.py` 啟動 Discord Bot、初始化 SQLite 並同步 slash commands。
- `cogs/` 處理指令、權限、冷卻及輸入。
- `services/` 提供標籤分析、SQLite CRUD、搜尋與 Discord 回覆。
- `scripts/test_extract_tags.py` 保留原命令列使用方式。
- `tests/` 包含 Provider、資料庫、搜尋和 Discord 指令的測試。


## 使用 MemeStack

在 MemeStack 開發者頁面申請 API 金鑰，填入本機 .env 的 MEMESTACK_API_KEY 後重啟。自建庫無可用圖片時，Bot 會使用 MemeStack 搜尋，並顯示連回結果頁的 via MemeStack。金鑰留白時可透過 WIKIMEDIA_CONTACT 使用 Commons。MemeStack 免費額度每日 100 次，圖片仍屬原權利人。

https://memestack.ai/developers
MemeStack 圖片以附件顯示。請允許 Bot 在使用頻道的 Attach Files（附加檔案）權限。


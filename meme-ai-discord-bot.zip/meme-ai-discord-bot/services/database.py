import json
import sqlite3
from contextlib import closing, contextmanager
from pathlib import Path

from models.meme import Meme


class DatabaseError(RuntimeError):
    pass


class DuplicateMeme(DatabaseError):
    pass


class Database:
    def __init__(self, path: Path):
        self.path = path

    @contextmanager
    def connection(self):
        try:
            with closing(sqlite3.connect(self.path)) as conn, conn:
                conn.row_factory = sqlite3.Row
                yield conn
        except sqlite3.Error as exc:
            raise DatabaseError("無法操作梗圖資料庫。") from exc

    def initialize(self):
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise DatabaseError("無法建立梗圖資料庫目錄。") from exc
        with self.connection() as conn:
            conn.execute("""
                CREATE TABLE IF NOT EXISTS memes (
                    id INTEGER PRIMARY KEY,
                    guild_id INTEGER NOT NULL,
                    image_url TEXT NOT NULL,
                    tags TEXT NOT NULL,
                    description TEXT NOT NULL,
                    source TEXT NOT NULL,
                    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
                    UNIQUE (guild_id, image_url)
                )
            """)

    def add(self, guild_id: int, meme: Meme) -> int:
        with self.connection() as conn:
            cursor = conn.execute("""
                INSERT INTO memes (guild_id, image_url, tags, description, source)
                VALUES (?, ?, ?, ?, ?) ON CONFLICT (guild_id, image_url) DO NOTHING
            """, (guild_id, meme.image_url, json.dumps(meme.tags), meme.description, meme.source))
            if not cursor.rowcount:
                raise DuplicateMeme("這個圖片網址已存在。")
            return cursor.lastrowid

    @staticmethod
    def from_row(row: sqlite3.Row) -> Meme:
        return Meme(row["image_url"], tuple(json.loads(row["tags"])),
                    row["description"], row["source"], row["id"], row["created_at"])

    def get(self, guild_id: int, meme_id: int) -> Meme | None:
        with self.connection() as conn:
            row = conn.execute("SELECT * FROM memes WHERE guild_id = ? AND id = ?",
                               (guild_id, meme_id)).fetchone()
            return self.from_row(row) if row else None

    def delete(self, guild_id: int, meme_id: int) -> bool:
        with self.connection() as conn:
            return bool(conn.execute("DELETE FROM memes WHERE guild_id = ? AND id = ?",
                                     (guild_id, meme_id)).rowcount)

    def search(self, guild_id: int, tags: list[str]) -> list[Meme]:
        with self.connection() as conn:
            rows = conn.execute("""
                SELECT memes.*, (
                    SELECT COUNT(DISTINCT value) FROM json_each(memes.tags)
                    WHERE value IN (SELECT value FROM json_each(?))
                ) AS score
                FROM memes WHERE guild_id = ? AND score > 0
                ORDER BY score DESC, id DESC
            """, (json.dumps(tags), guild_id))
            return [self.from_row(row) for row in rows]


import asyncio
from time import monotonic
from urllib.parse import urlsplit

import httpx

from models.meme import Meme
from services.database import Database

IMAGE_TYPES = {"image/jpeg", "image/png", "image/gif", "image/webp"}


class SearchError(RuntimeError):
    pass


def https_host(url: str) -> str | None:
    if len(url) > 2000 or any(char.isspace() or ord(char) < 32 for char in url) or "\\" in url:
        return None
    try:
        parts = urlsplit(url)
        if (parts.scheme == "https" and parts.netloc == parts.hostname
                and parts.path.startswith("/") and not parts.fragment):
            return parts.hostname
    except ValueError:
        pass
    return None


async def image_available(client: httpx.AsyncClient, url: str, hosts: set[str]) -> bool:
    if https_host(url) not in hosts:
        return False
    try:
        response = await client.head(url, follow_redirects=False)
        content_type = response.headers.get("content-type", "").split(";")[0].lower()
        return response.is_success and content_type in IMAGE_TYPES
    except httpx.HTTPError:
        return False


class CommonsSearch:
    def __init__(self, client: httpx.AsyncClient, contact: str):
        self.client = client
        self.contact = contact
        self.next_request = 0.0
        self.last_request = 0.0
        self.lock = asyncio.Lock()

    async def search(self, tags: list[str]) -> Meme | None:
        if not self.contact:
            return None
        for tag in tags:
            async with self.lock:
                if monotonic() < self.next_request:
                    raise SearchError("網路梗圖搜尋正在冷卻，請稍後再試。")
                await asyncio.sleep(max(0.0, self.last_request + 1 - monotonic()))
                self.last_request = monotonic()
                try:
                    response = await self.client.get(
                        "https://commons.wikimedia.org/w/api.php",
                        headers={"User-Agent": f"MemeAIDiscord/1.0 ({self.contact})"},
                        params={
                            "action": "query", "generator": "search",
                            "gsrsearch": tag.replace("_", " "), "gsrnamespace": 6,
                            "gsrlimit": 5, "prop": "imageinfo",
                            "iiprop": "url|mime|extmetadata",
                            "iiextmetadatafilter": "LicenseShortName|Restrictions|AttributionRequired",
                            "format": "json", "formatversion": 2,
                        },
                    )
                    if response.status_code in (429, 503):
                        retry = response.headers.get("Retry-After", "")
                        seconds = max(60, int(retry)) if retry.isascii() and retry.isdigit() and len(retry) < 10 else 60
                        self.next_request = monotonic() + seconds
                    response.raise_for_status()
                    payload = response.json()
                    if "error" in payload:
                        raise SearchError("網路梗圖 API 暫時無法使用。")
                    pages = sorted(payload.get("query", {}).get("pages", []),
                                   key=lambda page: page.get("index", 0))
                    for page in pages:
                        for info in page.get("imageinfo", []):
                            meme = self.result(info, tag)
                            if meme:
                                return meme
                except (httpx.HTTPError, ValueError, TypeError, AttributeError) as exc:
                    raise SearchError("網路梗圖 API 暫時無法使用。") from exc
        return None

    @staticmethod
    def result(info: dict, tag: str) -> Meme | None:
        metadata = info.get("extmetadata", {})
        license_name = metadata.get("LicenseShortName", {}).get("value")
        image_url = info.get("url", "")
        source = info.get("descriptionurl", "")
        if (license_name in {"CC0", "CC0 1.0", "Public domain"}
                and not metadata.get("Restrictions", {}).get("value")
                and metadata.get("AttributionRequired", {}).get("value") != "true"
                and info.get("mime") in IMAGE_TYPES
                and https_host(image_url) == "upload.wikimedia.org"
                and https_host(source) == "commons.wikimedia.org"):
            return Meme(image_url, (tag,), f"Wikimedia Commons · {license_name}", source)
        return None


class MemeSearch:
    def __init__(self, database: Database, web: CommonsSearch, image_hosts: set[str]):
        self.database = database
        self.web = web
        self.image_hosts = image_hosts

    async def search(self, guild_id: int, tags: list[str]) -> Meme | None:
        local = await asyncio.to_thread(self.database.search, guild_id, tags)
        for meme in local[:5]:
            if await image_available(self.web.client, meme.image_url, self.image_hosts):
                return meme
        return await self.web.search(tags)



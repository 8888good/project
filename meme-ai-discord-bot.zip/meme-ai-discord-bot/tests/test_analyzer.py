from types import SimpleNamespace as NS
from unittest.mock import MagicMock

import pytest
from google import genai
import openai

from services.analyzer import TagExtractionError, extract_meme_tags


@pytest.mark.parametrize("provider", ["gemini", "openai"])
def test_provider(monkeypatch, provider):
    client = MagicMock()
    tags = ["doge", "this_is_fine"]
    if provider == "gemini":
        monkeypatch.setenv("GEMINI_API_KEY", "test")
        monkeypatch.setattr(genai, "Client", lambda **kwargs: client)
        call = client.models.generate_content
        call.return_value = NS(parsed={"tags": tags})
    else:
        monkeypatch.setenv("OPENAI_API_KEY", "test")
        monkeypatch.setattr(openai, "OpenAI", lambda **kwargs: client)
        call = client.chat.completions.create
        call.return_value = NS(choices=[NS(message=NS(content='{"tags":["doge","this_is_fine"]}'))])

    assert extract_meme_tags("這很正常", provider, "custom-model") == {"tags": tags}
    assert call.call_args.kwargs["model"] == "custom-model"
    call.side_effect = RuntimeError("secret")
    with pytest.raises(TagExtractionError, match="API 呼叫失敗") as error:
        extract_meme_tags("聊天", provider)
    assert "secret" not in str(error.value)


@pytest.mark.parametrize("tags", [
    ["doge"], ["doge", " DOGE "], ["狗", "doge"], ["doge", "stonks", "crying_cat"]
])
def test_invalid_output(monkeypatch, tags):
    monkeypatch.setenv("GEMINI_API_KEY", "test")
    client = MagicMock()
    monkeypatch.setattr(genai, "Client", lambda **kwargs: client)
    client.models.generate_content.return_value = NS(parsed={"tags": tags})
    with pytest.raises(TagExtractionError, match="格式錯誤"):
        extract_meme_tags("聊天", "gemini")


import asyncio
from types import SimpleNamespace as NS
from unittest.mock import AsyncMock, Mock

import discord
import pytest
from discord import app_commands

from cogs.admin_commands import AdminCommands
from cogs.meme_commands import MemeCommands
from models.meme import Meme
from services.discord_service import Recommendations


def interaction():
    return NS(
        guild_id=1, user=NS(id=2), created_at=discord.utils.utcnow(),
        response=NS(defer=AsyncMock(), is_done=Mock(return_value=True)),
        followup=NS(send=AsyncMock()),
    )


def test_meme(monkeypatch):
    analyze = Mock(return_value={"tags": ["doge", "stonks"]})
    monkeypatch.setattr("services.discord_service.extract_meme_tags", analyze)
    url = "https://i.imgur.com/a.gif"
    search = Mock(search=AsyncMock(return_value=Meme(url, ("doge",), "", url)))
    cog = MemeCommands(Recommendations(search))
    event = interaction()
    asyncio.run(cog.meme.callback(cog, event, "看漲"))
    event.response.defer.assert_awaited_once()
    analyze.assert_called_once_with("看漲")
    assert event.followup.send.call_args.kwargs["embed"].image.url == url


def test_recent():
    def message(text, bot=False):
        return NS(content=text, author=NS(bot=bot), webhook_id=None)

    async def history(*, limit):
        assert limit == 12
        for item in (message("結果"), message("bot", bot=True), message("原因")):
            yield item

    event = interaction()
    event.channel = Mock(spec=discord.TextChannel, history=history)
    event.permissions = event.app_permissions = discord.Permissions(read_message_history=True)
    recommendations = Mock(send=AsyncMock())
    cog = MemeCommands(recommendations)
    asyncio.run(cog.meme_recent.callback(cog, event))
    recommendations.send.assert_awaited_once_with(event, "訊息 1：原因\n訊息 2：結果")


def test_admin_permissions():
    async def run():
        event = interaction()
        cog = AdminCommands(Mock(), Mock(), {"i.imgur.com"})
        event.permissions = discord.Permissions.none()
        with pytest.raises(app_commands.MissingPermissions):
            await cog.meme_add._check_can_run(event)
        event.permissions = discord.Permissions(manage_guild=True)
        assert await cog.meme_add._check_can_run(event)

    asyncio.run(run())



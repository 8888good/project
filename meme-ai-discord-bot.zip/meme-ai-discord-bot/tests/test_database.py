import pytest

from models.meme import Meme
from services.database import Database, DuplicateMeme


@pytest.fixture
def database(tmp_path):
    database = Database(tmp_path / "data" / "memes.db")
    database.initialize()
    return database


def test_crud_and_ranking(database):
    both = Meme("https://i.imgur.com/a.gif", ("doge", "stonks"), "", "https://i.imgur.com/a.gif")
    one = Meme("https://i.imgur.com/b.gif", ("doge",), "", "https://i.imgur.com/b.gif")
    first = database.add(1, both)
    second = database.add(1, one)
    assert database.get(1, first).created_at
    assert [meme.id for meme in database.search(1, ["doge", "stonks"])] == [first, second]
    assert not database.search(2, ["doge"])
    assert not database.delete(2, first)
    with pytest.raises(DuplicateMeme):
        database.add(1, both)
    assert database.delete(1, first)
    assert database.get(1, first) is None


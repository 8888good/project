import asyncio
import re

import discord
import httpx
from discord import app_commands
from discord.ext import commands

from models.meme import Meme
from services.database import Database, DatabaseError
from services.discord_service import reply
from services.meme_search import https_host, image_available


class AdminCommands(commands.Cog):
    def __init__(self, database: Database, client: httpx.AsyncClient, image_hosts: set[str]):
        self.database = database
        self.client = client
        self.image_hosts = image_hosts

    @app_commands.command(description="新增一張自建梗圖（管理伺服器權限）")
    @app_commands.guild_only()
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.checks.cooldown(1, 5, key=lambda i: i.user.id)
    @app_commands.checks.has_permissions(manage_guild=True)
    async def meme_add(
        self, interaction: discord.Interaction, image_url: str, tags: str,
        description: app_commands.Range[str, 0, 500] = "",
    ):
        image_url = image_url.strip()
        if https_host(image_url) not in self.image_hosts:
            await reply(interaction, "請使用允許的圖片主機及直接 HTTPS 圖片網址。")
            return
        cleaned = tuple(dict.fromkeys(part.strip().lower() for part in tags.split(",")))
        if not 1 <= len(cleaned) <= 10 or any(
            len(tag) > 64 or not re.fullmatch(r"[a-z][a-z0-9]*(?:_[a-z0-9]+)*", tag)
            for tag in cleaned
        ):
            await reply(interaction, "請提供 1 至 10 個以逗號分隔的英文 snake_case 標籤。")
            return
        await interaction.response.defer(ephemeral=True, thinking=True)
        if not await image_available(self.client, image_url, self.image_hosts):
            await reply(interaction, "無法確認圖片可用。請檢查直接圖片網址及格式。")
            return
        try:
            meme_id = await asyncio.to_thread(
                self.database.add, interaction.guild_id, Meme(image_url, cleaned, description, image_url)
            )
        except DatabaseError as exc:
            await reply(interaction, str(exc))
            return
        await reply(interaction, f"已新增梗圖 #{meme_id}。")


